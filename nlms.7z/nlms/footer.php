<?php include('connection.php');?>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/sticky-footer/">
    <!-- Bootstrap core CSS -->
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="sticky-footer.css" rel="stylesheet">
  </head>
	<footer class="page-footer font-small blue pt-4">
		<div class="footer-copyright text-center py-3">
			Nasi Lemak Warisan Mak Sarah
		</div>
	</footer>
</html>
