<?php
$conn = mysqli_connect("localhost","root","","nslm");

if(!$conn)
{
	echo "Database connection failed...";
}
?>